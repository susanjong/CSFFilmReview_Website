--
-- PostgreSQL database dump
--

-- Dumped from database version 17rc1
-- Dumped by pg_dump version 17rc1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: endgame_review; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.endgame_review (
    id integer NOT NULL,
    komentar text NOT NULL,
    bintang smallint,
    tanggal timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Jakarta'::text),
    CONSTRAINT review_bintang_check CHECK (((bintang >= 1) AND (bintang <= 5)))
);


ALTER TABLE public.endgame_review OWNER TO postgres;

--
-- Name: review_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.review_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.review_id_seq OWNER TO postgres;

--
-- Name: review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.review_id_seq OWNED BY public.endgame_review.id;


--
-- Name: endgame_review id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endgame_review ALTER COLUMN id SET DEFAULT nextval('public.review_id_seq'::regclass);


--
-- Data for Name: endgame_review; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.endgame_review (id, komentar, bintang, tanggal) FROM stdin;
43	I LOVE THIS MOVIE A LOT	5	2024-10-20 17:25:16.039911
\.


--
-- Name: review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.review_id_seq', 43, true);


--
-- Name: endgame_review review_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endgame_review
    ADD CONSTRAINT review_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

